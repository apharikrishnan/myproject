import React from "react";
import { MDBCol, MDBContainer, MDBRow, MDBFooter } from "mdbreact";

const Footer = () => {

  return (
    <MDBFooter color="red" className="font-small footer123 pt-0">
      <MDBContainer>
        <MDBRow className="pt-5 mb-3 text-center d-flex justify-content-center">  
          <MDBCol md="2" className="b-3">
            <h6 className="title font-weight-bold">
              <a href="#!" className="links"> THE INDIAN CRAFT HOUSE </a> <br></br><br></br> 
              <ul>
                <li><a href="/">ABOUT US</a></li> <br></br>
                <li><a href="/">MISSION</a></li><br></br>
                <li><a href="/">CONTACT US</a></li><br></br>
                <li><a href="/">SELL WITH US </a></li><br></br>
                <li><a href="/">FAIR TRADE</a></li><br></br>
                <li><a href="/">TERM OF USE</a></li><br></br>
                <li><a href="/">DISCLAIMER</a></li><br></br>
                <li><a href="/">BLOG</a></li><br></br>
                <li><a href="/">SITE MAP</a></li><br></br>
              </ul>
              
            </h6>
          </MDBCol>
          <MDBCol md="2" className="b-3">
            <h6 className="title font-weight-bold">
              <a href="#!" className="links"></a>
             
            </h6>
          </MDBCol>
          <MDBCol md="2" className="b-3">
            <h6 className="title font-weight-bold">
              <a href="#!" className="links"> SHOP </a> <br></br> <br></br> 
              <ul>
                <li><a href="/"><b></b></a></li>
                <li><a href="/">MY ACCOUNT</a></li> <br></br>
                <li><a href="/">REWARD PROGRAMS</a></li><br></br>
                <li><a href="/">GIFT CARD</a></li><br></br>
                <li><a href="/">BULK ORDER</a></li><br></br>
                <li><hr /></li>
              </ul>
            </h6>
          </MDBCol>
          <MDBCol md="2" className="b-3">
            <h6 className="title font-weight-bold">
              <a href="#!" className="links"></a>
             
            </h6>
          </MDBCol>
          <MDBCol md="2" className="b-3">
            <h6 className="title font-weight-bold">
              <a href="#!" className="links">HELP</a> <br></br> <br></br> <hr/>
              <li><a href="/"><b></b></a></li>
                <li><a href="/">CUSTOMER SERVICE</a></li> <br></br>
                <li><a href="/">HOW TO ORDER</a></li><br></br>
                <li><a href="/">BILLING PAYMENT</a></li><br></br>
                <li><a href="/">SHIPPING AND DELIVERY </a></li><br></br>
                <li><a href="/">REFUND RETURN AND EXCHANGE</a></li><br></br>
                <li><a href="/">DISCOUNT & PROMOTION</a></li><br></br>
                <li><a href="/">FAQ</a></li><br></br>
            </h6>
          </MDBCol>
          {/* <MDBCol md="2" className="b-3">
            <h6 className="title font-weight-bold">
              <a href="#!" className="links">Contact</a>
            </h6>
          </MDBCol> */}
        </MDBRow>
        {/* <hr className="rgba-white-light" style={{ margin: "0 15%" }} /> */}
        <MDBRow className="d-flex text-center justify-content-center mb-md-0 mb-4">
          <MDBCol md="8" sm="12" className="mt-5">
            {/* <p style={{ lineHeight: "1.7rem" }}>
              Sed ut perspiciatis unde omnis iste natus error sit voluptatem
              accusantium doloremque laudantium, totam rem aperiam, eaque ipsa
              quae ab illo inventore veritatis et quasi architecto beatae
              vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia
              voluptas sit aspernatur aut odit aut fugit, sed quia
              consequuntur.
            </p> */}
          </MDBCol>
        </MDBRow>
        <hr className="clearfix d-md-none rgba-white-light" style={{ margin: "10% 15% 5%" }} />
      </MDBContainer>
      <div className="footer-copyright text-center py-3">
        <MDBContainer fluid>
          &copy; {new Date().getFullYear()} Copyright:
          <a href="https://www.MDBootstrap.com"> giftshop.com </a>
        </MDBContainer>
      </div>
    </MDBFooter>
  );
}

export default Footer;