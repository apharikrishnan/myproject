import React, { Component } from 'react'

export class Homescreen extends Component {
    render() {
        return (
            <div>
                <img src={"hsc.jpg"} width="100%" alt="HOMESCREEN"/>
            </div>
        )
    }
}

export default Homescreen
